package com.example.myapplication;

import com.journeyapps.barcodescanner.CaptureActivity;

public class Captureact extends CaptureActivity {
}
