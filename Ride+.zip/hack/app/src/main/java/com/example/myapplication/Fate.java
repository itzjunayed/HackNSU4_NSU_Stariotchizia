package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.maps.android.SphericalUtil;

public class Fate extends AppCompatActivity {
    FirebaseDatabase database;
    TextView fare;
    FirebaseAuth auth;
    AppCompatButton button;
    String flan1 = null, flong2 = null, slan1 = null, slong2 = null;
    boolean tick=true;
    int i=0;
    String [] getvvalue=new String[4];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth=FirebaseAuth.getInstance();
        setContentView(R.layout.activity_fate);
        database = FirebaseDatabase.getInstance("https://transport-d8ac9-default-rtdb.firebaseio.com/");
        button=findViewById(R.id.backactivity);
        getvalue();
          fare=findViewById(R.id.fare);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Fate.this,Useractivity.class);
                startActivity(intent);
            }
        });
    }


    public void getvalue() {


        database.getReference().child("cordinate").addValueEventListener(new ValueEventListener() {


            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                String flan, flong, slan, slong=null;
                 if(i<4) {
                     if (snapshot.exists()) {
                         for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                             getvvalue[i] = dataSnapshot.getValue().toString();
                             i++;

                             if(i==4){
                                 countvalue();
                             }
                         }
                     }
                 }





            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
    public  void countvalue(){




        LatLng latLng=new LatLng(Double.parseDouble(getvvalue[0]), Double.parseDouble(getvvalue[1]));
        LatLng secondlatLng=new LatLng(Double.parseDouble(getvvalue[2]), Double.parseDouble(getvvalue[3]));

      double distance;
        distance = SphericalUtil.computeDistanceBetween(latLng, secondlatLng);
//        Toast.makeText(Fate.this,String.valueOf(distance),Toast.LENGTH_LONG).show();
//        Toast.makeText(Fate.this,getvvalue[0],Toast.LENGTH_LONG).show();
//
//        Toast.makeText(Fate.this,getvvalue[1],Toast.LENGTH_LONG).show();
//
//        Toast.makeText(Fate.this,getvvalue[2],Toast.LENGTH_LONG).show();
//
//        Toast.makeText(Fate.this,getvvalue[3],Toast.LENGTH_LONG).show();

        fare.setText("Fare is "+(distance / 1000)*2.25+" "+"taka");
          database.getReference().child("Fare").child(auth.getUid()).push().setValue((distance / 1000)*2.25);
    }

    @Override
    public void onBackPressed() {

    }
}