package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Useractivity extends AppCompatActivity {
    FirebaseDatabase database;
    TextView fullname,email,fair,NID;
 AppCompatButton newride,logout;
 FirebaseAuth auth;

 String [] addvalue=new String[100];
 int k=0;
 String [] getvalue=new String[3];
 int i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_useractivity);
        newride=findViewById(R.id.newRide);
        fullname=findViewById(R.id.fullname11);
        email=findViewById(R.id.mail11e);
        fair=findViewById(R.id.fair1);
        NID=findViewById(R.id.NID23);
       logout=findViewById(R.id.logout);
        auth=FirebaseAuth.getInstance();
        database=FirebaseDatabase.getInstance("https://transport-d8ac9-default-rtdb.firebaseio.com/");
        newride.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Useractivity.this,qrcode.class);
                startActivity(intent);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               auth.signOut();

                Intent intent=new Intent(Useractivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
        database.getReference().child("Users").child(auth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {

                    if (i < 3) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            getvalue[i] = dataSnapshot.getValue().toString();
                            i++;

                            if (i == 3) {
                                countvalue();
                            }
                        }
                    }
                }
            }





            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        database.getReference().child("Fare").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                         for(DataSnapshot snapshot1:snapshot.getChildren()){

                             if(snapshot1.exists()){

                               String name=snapshot1.getKey();

                               database.getReference().child("Fare").child(name).addValueEventListener(new ValueEventListener() {
                                   @Override
                                   public void onDataChange(@NonNull DataSnapshot snapshot3) {

                                       for(DataSnapshot snapshot12:snapshot3.getChildren()) {
                                                    if(snapshot12.exists()) {
                                                      String l=snapshot12.getValue().toString();
                                                       addvalue[k]=l;
                                                       k++;
                                                    }
                                       }
                                       faremethod();
                                   }

                                   @Override
                                   public void onCancelled(@NonNull DatabaseError error) {

                                   }
                               });


                             }
                         }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
       database.getReference().child("mainfare").child(auth.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot snapshot) {
               if(snapshot.exists()) {
                   String k = snapshot.getValue().toString();
                      fair.setText("Total fair "+k+" taka");
               }else{
                   fair.setText("Total fair "+0.0+" taka");
               }



           }


           @Override
           public void onCancelled(@NonNull DatabaseError error) {

           }
       });



        database.getReference().child("NID").child(auth.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()) {
                    String k = snapshot.getValue().toString();
                    NID.setText("Nid: "+k);
                }



            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }



     public void countvalue(){

              fullname.setText("Full name:"+" "+getvalue[2]);
              email.setText("Email:"+" "+getvalue[0]);

     }
     public void faremethod(){
        double count=0;
                     for(int j=0;j<k;j++){

                        count=count+Double.parseDouble(addvalue[j]);
                     }


                     database.getReference().child("mainfare").child(auth.getUid()).setValue(count);
     }

    @Override
    public void onBackPressed() {

    }
}